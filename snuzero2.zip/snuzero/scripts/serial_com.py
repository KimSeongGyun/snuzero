#!/usr/bin/env python
# license removed for brevity

import rospy
import time
import serial
import math
from std_msgs.msg import String
from snuzero.msg import ser_com
from snuzero.msg import control

alive = 0
enc = []

def init():

    pub = rospy.Publisher('serial_topic', ser_com, queue_size=10)
    rospy.Subscriber("control_topic", control, callback)
    rospy.init_node('serial_com', anonymous=True)
    rate = rospy.Rate(50)
    msg = ser_com()
    
    with serial.Serial(port='/dev/ttyUSB0', 
                   baudrate=115200,
                   parity=serial.PARITY_NONE,
                   stopbits=serial.STOPBITS_ONE,
                   bytesize=serial.EIGHTBITS,
                   timeout=1) as ser:

        while not rospy.is_shutdown():
            
            msg=msg_update(msg,ser)

            print("#####Publisher Node#####")
            rospy.loginfo(msg)
            pub.publish(msg)
            
            serial_send(ser)
            rate.sleep()

    
    
def msg_update(msg,ser):
    
    raw_data = ser.read(18)
    data = []
    for i in range(0,18):
        data.append(hex(int(raw_data[i].encode('hex'),16)))
    am = int(data[3],16)
    estop = int(data[4],16)
    gear = int(data[5],16)
    
    if(len(data[9])>=4):
        steer = int(data[9],16) * 256 + int(data[8],16) + 1 - pow(2,15)
        steer = -float(steer)/71 +462
    else:
        steer = int(data[9],16) * 256 + int(data[8],16)
        steer = -float(steer)/71
    brake = int(data[10],16)
    encoder = int(data[14],16) * pow(256,3) + int(data[13],16) * pow(256,2) + int(data[12],16) * pow(256,1) + int(data[11],16)
    global alive
    alive = int(data[15],16)
     
    global enc
    radius = 0.2675 # meter scale
    distance = 2 * math.pi * radius
    enc.append(encoder)
    if(len(enc)>=20):
        speed = float(enc[19] - enc[15] + enc[14] - enc[10] + enc[9]-enc[5] + enc[4]-enc[0]) / float(100) * float(distance) # m/s
       
        enc.pop(0)
       
    else:
        speed = 0
        
    
    msg.am = am
    msg.estop = estop
    msg.gear = gear
    msg.brake = brake
    msg.speed = round(speed,3)
    msg.steer = round(steer,3)
    msg.encoder = encoder
    msg.alive = alive
    return msg

def serial_send(ser):
    am=1
    estop=0
    gear=2
    speed=2*10
    steer=0 * 71
    brake=1
    global alive
    data_array = bytearray([83, 84, 88, am, estop, gear, 0, speed, 0, steer, brake, alive, 13, 10])
    ser.write(data_array)
    
    
def callback(data):
    a = 1
           
if __name__ == '__main__':
    try:
        init()
    except rospy.ROSInterruptException:
        pass
